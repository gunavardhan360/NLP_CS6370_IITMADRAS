# Requirements
Make sure to install all the neccessary packages using the following command:
pip3 install -r requirements.txt

# Data/
Cranfield collection was downloaded from [here](http://ir.dcs.gla.ac.uk/resources/test_collections/cran/).
You can also find the folds we used in this folder under /folds.

# Getting Started
You can set Hyper-parameters in the `ranker.py` file. 
- Mode: Can be set to 'Full-ranker' and 'Re-ranker'
- MODEL_TYPE: We used the bert-base-uncased model but you can easily change it to any model listed 
- LEARNING_RATE: We tested values 2e-5, 2e-3, 2e-2 for our experiments 
- MAX_LENGTH: Indicates the BERT token limitation. We just tested values 32,64,128 due to hardware limitation.
- BATCH_SIZE: Indicates the batch size for fine-tuning. 
- EPOCHS: Indicates the epoch numbers for fine-tuning. 
We trained for only 1 epoch and batch-size 16.
`ranker.py` will run the experiment with chosen parameters.
